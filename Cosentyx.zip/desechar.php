<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<?php include 'parts/head.php'; $title_site = "Encuesta de satisfaccion<br> Cosentyx® ";?>

  <body>
    <main>
      <?php
  if(isset($_SESSION['valid'])) {     
    include("parts/connection.php");          
    $result = mysqli_query($mysqli, "SELECT * FROM login");
  ?>
      <?php include 'parts/navbar.php'; ?>
        <div>
          <div class="bg-light p-5-custom">
            <div class="col-sm-10 mx-auto">
              <div class="stepsContainer">
                <div class="stepCard">
                  <div class="container"><img src="./assets/images/desechar.png" alt="" style="width:100%;height:auto;max-width:400px"></div>
                </div>
              </div>
              <br>
              <div>
                <div class="stepCard">
                  <div class="container"><span style="color:#000">Es importante <b>desechar el aplicador</b> en un lugar seguro. Antes de desecharlo en la basura, introduzcalo en un contenedor plástico con la tapa cerrada</span></div>
                </div>
              </div>
              <br>
              <div class="container">
                <div class="row">
                  <div class="col- text-center" style="width:50%">
                    <a href="fotopage.php">
                      <button type="button" class="btn btn-outline-danger"><i class="fas fa-arrow-left"></i> Anterior</button>
                    </a>
                  </div>
                  <div class="col- text-center" style="width:50%">
                    <a href="reaccion.php">
                      <button type="button" class="btn btn-outline-danger">Siguiente <i class="fas fa-arrow-right"></i></button>
                    </a>
                  </div>
                </div>
              </div>
              <br>
              <?php include 'parts/modalsoporte.php'; ?>
                <div class="progress">
                  <div class="progress-bar bg-danger" style="width:80%"></div><span>Progreso</span></div>
                 <?php 
  } else {
    echo "Solo Usuarios Registrados.<br/><br/>";
    echo "<a href='index.php'>Inicio</a>";
  }
  ?>
                <?php include 'parts/footer.php'; ?>
            </div>
          </div>
        </div>
    </main>
    <script src="./dist/js/bootstrap.bundle.min.js"></script>
  </body>

</html>