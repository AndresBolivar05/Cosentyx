<?php session_start(); ?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <?php include 'parts/head.php'; $title_site = "Diagnóstico y dosis® ";?>
      <style>
        [type=radio]:checked+img {
          border: 3px solid #4e3260;
          border-radius: 5px;
          padding: 1px
        }
      </style>
  </head>


  <body>
    <main>
      <?php if(isset($_SESSION['valid'])) { include("parts/connection.php"); $result = mysqli_query($mysqli, "SELECT * FROM login"); ?>
        <?php include 'parts/navbar.php'; ?>
          <div>
            <div class="bg-light p-5-custom">
              <div class="col-sm-10 mx-auto">
                <div class="stepsContainer">
                  <div class="stepCard">
                    <div class="container">
                      <div class="row"><span style="color:#000">Por favor <b>indíquenos cuál es patología por la cual está usando Cosentyx®</b></span>
                        <br>
                      </div>
                      <br>
                      <div class="row">
                        <select class="form-control">
                          <option value="Psoriasis">Psoriasis</option>
<option value="Espondilitis Anquilosante">Espondilitis Anquilosante</option>
<option value="Artritis Psoriásica">Artritis Psoriásica</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <div class="stepsContainer">
                  <div class="stepCard">
                    <div class="container">
                      <div class="row"><span style="color:#000">¿<b>Que dosis</b> se está aplicando usted actualmente?</span></div>
                      <br>
                      <label>
                        <input type="radio" name="test" value="small" checked> <img src="./assets/images/150mg.png"></label>
                      <label>
                        <input type="radio" name="test" value="big"> <img src="./assets/images/300mg.png"></label>
                    </div>
                  </div>
                </div>
                <br>
                <div class="stepsContainer">
                  <div class="stepCard">
                    <div class="container">
                      <div class="row"><span style="color:#000">Esta aplicación es su dosis número:
</span>
                        <br>
                      </div>
                      <br>
                      <div class="row">
                        <select class="form-control">
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="5">4</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <div class="container">
                  <div class="row">
                    <div class="col- text-center" style="width:50%">
                      <a href="encuesta1.php">
                        <button type="button" class="btn btn-outline-danger"><i class="fas fa-arrow-left"></i> Anterior</button>
                      </a>
                    </div>
                    <div class="col- text-center" style="width:50%">
                      <a href="video.php">
                        <button type="button" class="btn btn-outline-danger">Siguiente <i class="fas fa-arrow-right"></i></button>
                      </a>
                    </div>
                  </div>
                </div>
                <br>
                <?php include 'parts/modalsoporte.php'; ?>
                  <div class="progress">
                    <div class="progress-bar bg-danger" style="width:10%"></div><span>Progreso</span></div>
                  <?php } else { echo "Solo Usuarios Registrados.<br/><br/>"; echo "<a href='index.php'>Inicio</a>"; } ?>
                    <?php include 'parts/footer.php'; ?>
              </div>
            </div>
          </div>
    </main>
    <script src="./dist/js/bootstrap.bundle.min.js"></script>
  </body>

  </html>