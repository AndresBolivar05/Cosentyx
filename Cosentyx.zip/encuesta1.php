<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<?php include 'parts/head.php'; 
$title_site = "Bienvenido a la autoaplicación <br> <img class='img-fluid' src='./assets/logos/logoblanco.png'  style='width: 150px;padding-bottom:10px;padding-top:5px;'>";?>
<body>
<main>

<?php
  if(isset($_SESSION['valid'])) {     
    include("parts/connection.php");          
    $result = mysqli_query($mysqli, "SELECT * FROM login");
  ?>


<?php include 'parts/navbar-enc.php'; ?>
<div>
  
<div class="bg-light p-5-custom">
<div class="col-sm-10 mx-auto">
<div>
<div class="stepCard" style="text-align:left;box-shadow:none;color:#000"><span>Por favor <b>conteste las siguientes preguntas antes de continuar:</b></span></div>
</div>
<form action="diagnostico.php" method="get" id="form-id">  
<div class="stepsContainer">
<div class="stepCard">
<p>¿Ha tenido fiebre usted en los últimos 3 días?</p>
<ul class="donate-now">
<li>
<input type="radio" id="Si1" name="q1" onclick="display()" value="0">
<label for="Si1">Si</label>
</li>
<li>
<input type="radio" id="No1" name="q1" checked value="1">
<label for="No1">No</label>
</li>
</ul>
</div>
</div>
<br>
<div class="stepsContainer">
<div class="stepCard">
<p>¿Ha presentado síntomas de gripa en estos últimos 3 días?</p>
<ul class="donate-now">
<li>
<input type="radio" id="Si2" name="q2" onclick="display2()">
<label for="Si2">Si</label>
</li>
<li>
<input type="radio" id="No2" name="q2"  checked>
<label for="No2">No</label>
</li>
</ul>
</div>
</div>
<br>
<div class="stepsContainer">
<div class="stepCard">
<p>¿Se encuentra en antibióticos actualmente?</p>
<ul class="donate-now">
<li>
<input type="radio" id="Si3" name="q3"  onclick="display3()">
<label for="Si3">Si</label>
</li>
<li>
<input type="radio" id="No3" name="q3" checked>
<label for="No3">No</label>
</li>
</ul>
</div>
</div>
<br>
<div class="stepsContainer">
<div class="stepCard">
<p>¿Tiene sarpullido donde normalmente se aplica Cosentyx?</p>
<ul class="donate-now">
<li>
<input type="radio" id="Si4" name="q4"  onclick="display4()">
<label for="Si4">Si</label>
</li>
<li>
<input type="radio" id="No4" name="q4" checked>
<label for="No4">No</label>
</li>
</ul>
</div>
</div>
<br>
<div class="container">
<div class="row">
<div class="col- text-center" style="width:50%">
<a href="index.php">
<button type="button" class="btn btn-outline-danger"><i class="fas fa-arrow-left"></i> Anterior</button>
</a>
</div>
<div class="col- text-center" style="width:50%">

<button type="button" id="your-id"  class="btn btn-outline-danger">Siguiente <i class="fas fa-arrow-right"></i></button>
</a>
</form>
</div>
</div>
</div>
<br>
<?php include 'parts/modalsoporte.php'; ?>
<div class="progress">
<div class="progress-bar bg-danger" style="width:0"></div><span>Progreso</span></div>

</div>
</div>
</div>
<?php 
  } else {
    echo "Solo Usuarios Registrados.<br/><br/>";
    echo "<a href='index.php'>Inicio</a>";
  }
  ?>
  <?php include 'parts/footer.php'; ?>
</main>

<script>


var form = document.getElementById("form-id");

document.getElementById("your-id").addEventListener("click", function () {
  form.submit();
});

function display() { 
            var checkRadio = document.querySelector('input[name="q1"]:checked');

            if(checkRadio != null) {
                document.getElementById("form-id").setAttribute("action", "finalno.php"); 
                document.getElementById("form-id").setAttribute( "method" , "post"); 
            }
            
        }

function display2() { 

            var checkRadio2 = document.querySelector('input[name="q2"]:checked');

            if(checkRadio2 != null) {
                document.getElementById("form-id").setAttribute("action", "finalno.php");
                document.getElementById("form-id").setAttribute( "method" , "post");  
            }
            
        }

function display3() { 

            var checkRadio3 = document.querySelector('input[name="q3"]:checked');


            if(checkRadio3 != null) {
                document.getElementById("form-id").setAttribute("action", "finalno.php");
                document.getElementById("form-id").setAttribute( "method" , "post");  
            }
            
        }

        function display4() { 

            var checkRadio4 = document.querySelector('input[name="q4"]:checked');


            if(checkRadio4 != null) {
                document.getElementById("form-id").setAttribute("action", "finalno.php"); 
                document.getElementById("form-id").setAttribute( "method" , "post"); 
            }
            
        }


    </script>
<script src="./dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
