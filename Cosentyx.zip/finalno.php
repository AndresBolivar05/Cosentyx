<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<?php include 'parts/head.php'; 
$title_site = "Encuesta de satisfaccion<br>
Cosentyx® ";?>
</head>
<body>
<main>
<?php
  if(isset($_SESSION['valid'])) {     
    include("parts/connection.php");          
    $result = mysqli_query($mysqli, "SELECT * FROM login");
  ?>


<?php include 'parts/navbar.php'; ?>
<div>
<div class="bg-light p-5-custom">
<div class="col-sm-10 mx-auto">
<div>
<div class="stepCard">
<div class="container">
<div class="row">
<div class="col-md-12">
<h3>Gracias!</h3><img src="./assets/logos/check.png" class="img-fluid" style="padding:30%;padding-top:15px;padding-bottom:15px">
<h4> Por favor consulte a su médico para mas información </h4><img src="./assets/images/cosentyxexp.png" class="img-fluid" style="padding:30%;padding-top:15px;padding-bottom:15px"></div>
</div>
</div>
</div>
</div>
<br>
<?php include 'parts/modalsoporte.php'; ?>
<div class="progress">
<div class="progress-bar bg-danger" role="progressbar" style="width:100%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">Progreso</div>
</div>
</div>
</div>
</div>
<?php 
  } else {
    echo "Solo Usuarios Registrados.<br/><br/>";
    echo "<a href='index.php'>Inicio</a>";
  }
  ?>
<?php include 'parts/footer.php'; ?>
</main>
<script src="./dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>