<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<?php $title_site = "Registro aplicacion <br>Cosentyx";

include 'parts/head.php';
 ?>


<style>
    #my_camera {
    padding: 0;
    width: 320px;
    height: 240px;



}
    .displayhide {
  display: none;
}

</style>

</head>
<body onload="configure()">
<main style="
    justify-content: start;
">
    
<?php
  if(isset($_SESSION['valid'])) {     
    include("parts/connection.php");          
    $result = mysqli_query($mysqli, "SELECT * FROM login");
  ?>

    <?php include 'parts/navbar.php'; ?>
      <div>
        <div class="bg-light p-5-custom" style="background:url(./assets/images/fondo-cosentux.png);background-size:cover;background-repeat:no-repeat;padding:0!important">
          <div class="col-sm-10 mx-auto">
            <div class="container" style="padding:0;">
              <div class="row" style="margin: 0 auto;">
                <div id="my_camera" class="displayhide" style="margin: 0 auto;"></div>
                <div id="results" class="displayhide" style="margin: 0 auto;text-align: center;"></div>

                <div class="row" style="margin-top:20px;z-index:9999">
                  <div style="
    margin: 0 auto;
    width: 320px;
">
                  <p style="text-align:center;background:#efefef99;border-radius:7px;width:320px;box-shadow:1px 2px 3px 0;margin-left:10px;height:60px;padding-top:7px;margin: 0 auto;">Tome una foto del aplicador
                    <br>Cosentyx Usado</p>
                  <div class="col-md-12" style="text-align:center">
                    <button class="shutter" onClick="take_snapshot()" style="border:0;background:0 0"><img class="img-fluid" style="width:60px;height:60px;margin-top:2px;margin-left:30px" src="./assets/logos/camera-logo.png"></button>


                    <button class="shutter displayhide" onClick="tomarotra()" id="botonreset" style="border:0;background:0 0"><img class="img-fluid" style="width:60px;height:60px;margin-top:2px;margin-left:30px" src="./assets/logos/redo-logo.png"></button>



          

  <input class="displayhide" type=button value="Guardar Foto" onClick="saveSnap()" id="botonguardar">

                  </div>
                  </div>
                </div>
  
  
    
              </div>
            </div>
            <div class="container">
              <div class="row">
                <div class="col- text-center" style="width:50%">
                  <a href="ar.php">
                    <button type="button" class="btn btn-outline-danger"><i class="fas fa-arrow-left"></i> Anterior</button>
                  </a>
                </div>
                <div class="col- text-center" style="width:50%">
                  <a href="desechar.php">
                    <button type="button" class="btn btn-outline-danger" onClick="saveSnap()">Siguiente <i class="fas fa-arrow-right"></i></button>
                  </a>
                </div>
              </div>
            </div>
            <br>
            <?php include 'parts/modalsoporte.php'; ?>
            <div class="progress">
              <div class="progress-bar bg-danger" style="width:50%"></div><span>Progreso</span></div>
            <?php 
  } else {
    echo "Solo Usuarios Registrados.<br/><br/>";
    echo "<a href='index.php'>Inicio</a>";
  }
  ?>
            <?php include 'parts/footer.php'; ?>
          </div>
        </div>
      </div>
  </main>

<script type="text/javascript" src="webcamjs/webcam.min.js"></script>

  <!-- Code to handle taking the snapshot and displaying it locally -->
  <script language="JavaScript">
    
    // Configure a few settings and attach camera
    function configure(){
      var camara = document.getElementById("my_camera");
      camara.classList.toggle("displayhide");

      Webcam.set({


    dest_width: 320,
    dest_height: 240,
    image_format: 'jpeg',
    jpeg_quality: 90,
    force_flash: false

      });
      Webcam.attach( '#my_camera' );
    }


    function tomarotra(){
      var camara = document.getElementById("my_camera");
      camara.classList.toggle("displayhide");

      var camara = document.getElementById("results");
      camara.classList.toggle("displayhide");

      var camara = document.getElementById("botonreset");
      camara.classList.toggle("displayhide");

      Webcam.set({

        image_format: 'jpeg',
        jpeg_quality: 90
      });
      Webcam.attach( '#my_camera' );
    }
    // A button for taking snaps
    

    // preload shutter audio clip
    var shutter = new Audio();
    shutter.autoplay = false;
    shutter.src = navigator.userAgent.match(/Firefox/) ? 'shutter.ogg' : 'shutter.mp3';

    function take_snapshot() {

      var element = document.getElementById("botonreset");
   element.classList.toggle("displayhide");

      var element = document.getElementById("results");
   element.classList.toggle("displayhide");


      var element = document.getElementById("my_camera");
   element.classList.toggle("displayhide");

      // play sound effect
      shutter.play();

      // take snapshot and get image data
      Webcam.snap( function(data_uri) {
        // display results in page
        document.getElementById('results').innerHTML = 
          '<img id="imageprev" src="'+data_uri+'"/>';
      } );

      Webcam.reset();
    }

    function saveSnap(){
      // Get base64 value from <img id='imageprev'> source
      var base64image =  document.getElementById("imageprev").src;

       Webcam.upload( base64image, 'upload.php', function(code, text) {
         console.log('Save successfully');
         //console.log(text);
            });

    }
  </script>

  <script src="./scripts/camara.js"></script>
  <script src="./dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>