<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<?php include 'parts/head.php'; 
$title_site = "Encuesta de satisfaccion<br>
Cosentyx® ";?>
</head>

<body>
  <main>
    <?php
  if(isset($_SESSION['valid'])) {     
    include("parts/connection.php");          
    $result = mysqli_query($mysqli, "SELECT * FROM login");
  ?>

    <?php include 'parts/navbar.php'; ?>
    <div>
      <div class="bg-light p-5-custom">
        <div class="col-sm-10 mx-auto">
          <div class="stepsContainer">
            <div class="stepCard">
              <div class="container">
                <div class="row">
                  <div class="divhistorial">
                    <table class="table table-sm" style="margin-bottom:0">
                      <tbody>
                        <tr>
                          <td><img src="./assets/logos/yeslogo.png" alt="" style="width:15px;height:auto">Aplicada</td>
                          <td>11 de Enero</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="table table-sm" style="margin-bottom:0">
                      <tr>
                        <td style="background-color:#3c2052!important;color:#fff">Aplicada</td>
                      </tr>
                    </table>
                  </div>
                  <div class="divhistorial">
                    <table class="table table-sm" style="margin-bottom:0">
                      <tbody>
                        <tr>
                          <td><img src="./assets/logos/yeslogo.png" alt="" style="width:15px;height:auto">Aplicada</td>
                          <td>11 de Febrero</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="table table-sm" style="margin-bottom:0">
                      <tr>
                        <td style="background-color:#3c2052!important;color:#fff">Aplicada</td>
                      </tr>
                    </table>
                  </div>
                  <div class="divhistorial">
                    <table class="table table-sm" style="margin-bottom:0">
                      <tbody>
                        <tr>
                          <td><img src="./assets/logos/danger.png" alt="" style="width:15px;height:auto">No Aplicada</td>
                          <td>11 de Marzo</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="table table-sm" style="margin-bottom:0">
                      <tr>
                        <td style="background-color:#3c2052!important;color:#fff">No Aplicada</td>
                      </tr>
                    </table>
                  </div>
                  <div class="divhistorial">
                    <table class="table table-sm" style="margin-bottom:0">
                      <tbody>
                        <tr>
                          <td><img src="./assets/logos/warning.png" alt="" style="width:15px;height:auto">Por aplicar</td>
                          <td>11 de abril</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="table table-sm" style="margin-bottom:0">
                      <tr>
                        <td style="background-color:#3c2052!important;color:#fff">Por aplicar</td>
                      </tr>
                    </table>
                  </div>
                  <div class="divhistorial">
                    <table class="table table-sm" style="margin-bottom:0">
                      <tbody>
                        <tr>
                          <td><img src="./assets/logos/warning.png" alt="" style="width:15px;height:auto">Por aplicar</td>
                          <td>11 de Mayo</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="table table-sm" style="margin-bottom:0">
                      <tr>
                        <td style="background-color:#3c2052!important;color:#fff">Por aplicar</td>
                      </tr>
                    </table>
                  </div>
                  <div class="divhistorial">
                    <table class="table table-sm" style="margin-bottom:0">
                      <tbody>
                        <tr>
                          <td><img src="./assets/logos/warning.png" alt="" style="width:15px;height:auto">Por aplicar</td>
                          <td>11 de Junio</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="table table-sm" style="margin-bottom:0">
                      <tr>
                        <td style="background-color:#3c2052!important;color:#fff">Por aplicar</td>
                      </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <br>
            <?php include 'parts/modalsoporte.php'; ?>
          </div>
          <?php 
  } else {
    echo "Solo Usuarios Registrados.<br/><br/>";
    echo "<a href='index.php'>Inicio</a>";
  }
  ?>
          <?php include 'parts/footer.php'; ?>
        </div>
      </div>
    </div>
  </main>
  <script src="./dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>