<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<?php include("parts/connection.php"); ?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Hugo 0.82.0">
  <title>Cosentyx</title>
  <link href="./styles/style.css" rel="stylesheet" type="text/css">
  <link href="./styles/homestyle.css" rel="stylesheet" type="text/css">
  <link href="./dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous">
</head>

<body>
  <main style="background:url(assets/images/fondo-1.png);background-size:cover">
    <div>
      <div class="p-5-custom">
        <div class="col-sm-10 mx-auto">
          <div style="text-align:center">
            <div class="container"><img src="assets/logos/novartis-new-logo.png">
              <div class="subContainter">
                <h2>Bienvenido a la herramienta de autoaplicación</h2>
                <p>Ingrese el PIN asignado por su IPS</p>

<?php


if(isset($_POST['submit'])) {
  $user = mysqli_real_escape_string($mysqli, $_POST['codigo']);

  if($user == "" ) {
    echo "Error.";
    echo "<br/>";
    echo "<a href='index.php'>Regresar</a>";
  } else {
    $result = mysqli_query($mysqli, "SELECT * FROM login WHERE codigo='$user'")
          or die("Could not execute the select query.");
    
    $row = mysqli_fetch_assoc($result);
    
    if(is_array($row) && !empty($row)) {
      $validuser = $row['codigo'];
      $_SESSION['valid'] = $validuser;
      $_SESSION['id'] = $row['id'];
    } else {
      echo "Invalid codigo.";
      echo "<br/>";
      echo "<a href='index.php'>Regresar</a>";
    }

    if(isset($_SESSION['valid'])) {
     ?>
     <script type="text/javascript">
window.location="encuesta1.php";
</script>
<?php   
    }
  }
} else {
?>
<form name="form1" method="post" action="">
<input class="enterInput" type="number" name="codigo"> 
<input type="submit" class="enterButton" name="submit" value="Entrar">
</form>
<?php
}
?>
</div>
<div class="container anotherclass">
              <div style="color:#fff;font-size:11px">
                <p style="
    font-size: 10px;
">Novartis de Colombia S.A. Calle 93B No. 16-31. PBX 654 44 44. Bogotá, D.C. Novartis de Colombia S.A. Novartis Pharma, AG de Basilea, Suiza. ® = Marca registrada. Mayor información en el Departamento Medico de Novartis de Colombia S.A. Tel. 6544444. Material exclusivo para uso de pacientes. No se autoriza la grabación o toma de fotografías del material y tampoco difusión por medios no autorizados por Novartis. Fecha de aprobación: XXXXXX. Fecha de caducidad: XXXXXX. Código de aprobación P3: XXXXXX. Si desea reportar un evento adverso ingrese al siguiente link: https://www.report.novartis.com/es o a través del correo electrónico: colombia.farmacovigilancia@novartis.com</p>
              </div>
            </div>
          </div>
          <br>
        </div>
      </div>
    </div>
  </main>
  <script src="./dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>