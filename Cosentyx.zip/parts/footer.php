<div class="container footer"> 
  <div class="row">
<div class="col-md-6-custom" style="width: 50%;float: left;"><img class="image-responsive" src="./assets/logos/novartis-new-logo-old.png" ></div>
<div class="col-md-6-custom" style="width: 50%;float: right;"><span type="" class="" data-bs-toggle="modal" data-bs-target="#modalinfo"><p style="text-align: center;padding-top: 7px;font-size: 13px;color: #5190c2;">Click para más información&nbsp;</p></span></div>
  	
  </div>
</div>








<div class="modal fade" id="modalinfo" tabindex="-1" aria-labelledby="modalinfo" aria-hidden="true">
	<div class="modal-dialog" style="
    padding-top: 10px;
">
		<div class="modal-content">
			<div class="modal-header" style="padding-bottom:0">
				<h5 class="modal-title" id="modalinfo" style="width:100%"><span type="" data-bs-toggle="modal" data-bs-target="#modalinfo"><img class="img-fluid" src="./assets/logos/novartis-new-logo-old.png" alt="" style="width:200px"></span> </h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="padding-top:0;margin-top:-45px;margin-right:-15px"></button>
			</div>
			<div class="modal-body" style="font-size:12px;font-weight:600"><p>
            Novartis de Colombia S.A. Calle 93B No. 16-31. PBX 654 44 44.
            Bogotá, D.C. Novartis de Colombia S.A. Novartis Pharma, AG de
            Basilea, Suiza. ® = Marca registrada. Mayor información en el
            Departamento Medico de Novartis de Colombia S.A. Tel. 6544444.
            Material exclusivo para uso de pacientes. No se autoriza la
            grabación o toma de fotografías del material y tampoco difusión por
            medios no autorizados por Novartis. Para mayor información consultar
            la información completa para la prescripción de Cosentyx (en la
            palabra Cosentyx debe haber un link que redirija a la sucinta que
            adjunté en el correo) Fecha de aprobación: XXXXXX. Fecha de
            caducidad: XXXXXX. Código de aprobación P3: XXXXXX. Si desea
            reportar un evento adverso ingrese al siguiente link:
            https://www.report.novartis.com/es o a través del correo
            electrónico: colombia.farmacovigilancia@novartis.com
          </p></div>

		</div>
	</div>
</div>