<div class="modal fade" id="modalSoporte" tabindex="-1" aria-labelledby="modalsoporte" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header" style="padding-bottom:0">
				<h5 class="modal-title" id="modalsoporte" style="width:100%"><span type="" data-bs-toggle="modal" data-bs-target="#modalSoporte"><img class="img-fluid" src="./assets/logos/soporte-logo.png" alt="" style="width:50px"></span> Linea de soporte</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="padding-top:0;margin-top:-45px;margin-right:-15px"></button>
			</div>
			<div class="modal-body" style="font-size:18px;font-weight:600">¿Quiere comunicarse con un representante de Sanitas para resolver cualquier duda?</div>
			<div class="container" style="text-align:center;padding-bottom:15px">
				<button class="btn btn-danger" style="width:90%">Llamar</button>
			</div>
		</div>
	</div>
</div>