<nav class="navbar navbar-dark header-bg"  style="    padding-bottom: 11.5rem;" aria-label="First navbar example">
<div class="container-fluid" style="
    padding: 0px;
    padding-left: 1px;
">
<div class="row" style="
    width: 100%;
">
<div class="col-md-6-custom" style="
    float: left;
    width: 50%;
"><button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample01" aria-controls="navbarsExample01" aria-expanded="false" aria-label="Toggle navigation" style="
border: 0px;">
<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" style="position: absolute;" id="navbarsExample01">
<ul class="navbar-nav me-auto mb-2 custom-class-nav" style="">
<li class="nav-item">
<a class="nav-link active linavitem-a" aria-current="page" href="encuesta1.php" >Dosis</a>
</li>
<li class="nav-item">
<a class="nav-link linavitem-ab" style="" href="historial.php">Historial</a>
</li>
</ul>
</div>
</div>

<div class="col-md-6-custom" style="
    float: right;
    width: 50%;
    text-align: right;
    padding-right: 0px;
"><span type="" class="" data-bs-toggle="modal" data-bs-target="#modalSoporte" style="color: gray;">

	<p style="
    width: 65%;
    float: left;
">
Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium </p><p style="width: 30%;;float: right;"> <img class="img-fluid" src="./assets/images/qr.png" alt="" style="width: 50px"></p></span></div>
</div>
<div class="row" style="
    width: 100%;
    text-align: center;
    margin-left: 5px;
">
<a class="navbar-brand" href="#" style="text-align: center;"><?php  echo $title_site; ?></a>
</div>


</div>


</nav>