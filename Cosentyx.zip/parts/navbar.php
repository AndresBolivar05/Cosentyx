<nav class="navbar navbar-dark header-bg" aria-label="First navbar example">
<div class="container-fluid">
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample01" aria-controls="navbarsExample01" aria-expanded="false" aria-label="Toggle navigation" style="
border: 0px;">
<span class="navbar-toggler-icon"></span>
</button>
<a class="navbar-brand" href="#" style="text-align: center;"><?php  echo $title_site; ?></a>
<span type="" class="" data-bs-toggle="modal" data-bs-target="#modalSoporte">
<span type="" class="" data-bs-toggle="modal" data-bs-target="#modalSoporte">
<img class="img-fluid" src="./assets/logos/soporte-logo.png" alt="" style="width: 50px;"></span></span>
<div class="collapse navbar-collapse" id="navbarsExample01">
<ul class="navbar-nav me-auto mb-2 custom-class-nav" style="">
<li class="nav-item">
<a class="nav-link active linavitem-a" aria-current="page" href="encuesta1.php" >Dosis</a>
</li>
<li class="nav-item">
<a class="nav-link linavitem-ab" style="" href="historial.php">Historial</a>
</li>
</ul>
</div>
</div>
</nav>