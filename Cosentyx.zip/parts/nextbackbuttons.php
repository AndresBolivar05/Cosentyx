<br>

<div class="container">
<div class="row">
<div class="col- text-center" style="width: 50%"><a href="reaccion.html"><button type="button" class="btn btn-outline-danger"><i class="fas fa-arrow-left"></i> Anterior</button></a>

</div>
<div class="col- text-center" style="width: 50%"><a href="final.html"><button type="button" class="btn btn-outline-danger">Siguiente <i class="fas fa-arrow-right"></i></button></a>

</div>
</div>
</div>

<br>