<div class="progress">
<div class="progress-bar bg-danger" style="width: 90%;">
</div>
<span>Progreso</span>
</div>