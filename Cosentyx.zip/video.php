<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<?php include 'parts/head.php'; 
$title_site = "Para esta experiencia<br> ";?>
</head>

<body>
  <main>
    <?php
  if(isset($_SESSION['valid'])) {     
    include("parts/connection.php");          
    $result = mysqli_query($mysqli, "SELECT * FROM login");
  ?>
    <?php include 'parts/navbar.php'; ?>
    <div>
      <div class="bg-light p-5-custom">
        <div class="col-sm-10 mx-auto">
          <div>
            <div>
              <div class="container">
                <div class="embed-responsive embed-responsive-16by9">
                  <video width="400" controls>
  <source src="assets/images/cosentyxvideoapp.mp4" type="video/mp4">
  Your browser does not support HTML video.
</video>
                </div>
              </div>
            </div>
          </div>
          <br>
          <div class="container">
            <div class="row">
              <div class="col- text-center" style="width:50%">
                <a href="diagnostico.php">
                  <button type="button" class="btn btn-outline-danger"><i class="fas fa-arrow-left"></i> Anterior</button>
                </a>
              </div>
              <div class="col- text-center" style="width:50%">
                <a href="welcome.php">
                  <button type="button" class="btn btn-outline-danger">Siguiente <i class="fas fa-arrow-right"></i></button>
                </a>
              </div>
            </div>
          </div>
          <br>
          <?php include 'parts/modalsoporte.php'; ?>
          <div class="progress">
            <div class="progress-bar bg-danger" style="width:20%"></div><span>Progreso</span></div>
           <?php 
  } else {
    echo "Solo Usuarios Registrados.<br/><br/>";
    echo "<a href='index.php'>Inicio</a>";
  }
  ?>
       
        </div>
           <?php include 'parts/footer.php'; ?>
      </div>
    </div>
  </main>
  <script src="./dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>